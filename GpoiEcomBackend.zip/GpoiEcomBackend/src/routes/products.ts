import { Router, Request, Response, RequestHandler } from 'express';
import { Firestore } from 'firebase-admin/firestore';
import { Product } from '../types/products';

export function createProductRouter(db: Firestore): Router {
  const router = Router();

  const getProducts: RequestHandler = async (req: Request, res: Response) => {
    try {
      const productsCollection = db.collection('products');
      const productSnapshot = await productsCollection.get();

      if (productSnapshot.empty) {
        res.status(200).json([]);
        return;
      }

      const products: Product[] = productSnapshot.docs.map(doc => ({
        id: doc.id,
        ...(doc.data() as Omit<Product, 'id'>)
      }));

      res.status(200).json(products);
    } catch (error) {
      console.error('Error fetching products:', error);
      res.status(500).json({ error: 'Failed to fetch products' });
    }
  };

  router.get('/', getProducts);

  return router;
}