import express from 'express';
import cors from 'cors';
import { Firestore } from 'firebase-admin/firestore';
import { createProductRouter } from './routes/products';

export function createApp(db: Firestore) {
  const app = express();

  // Middleware
  app.use(cors({
    origin: 'http://localhost:5173', // Replace with your localhost URL
  }));
  app.use(express.json());

  // Routes
  app.use('/api/products', createProductRouter(db));

  return app;
}